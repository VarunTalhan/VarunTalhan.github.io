## The Main code is under xai-sound-next as a Next.js app.
## Initial drafting for the React code was done in prototypes/harrison-xai.
## The Final draft is under prototypes/xai-project.
